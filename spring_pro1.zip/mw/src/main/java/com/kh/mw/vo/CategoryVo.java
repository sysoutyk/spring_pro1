package com.kh.mw.vo;

import lombok.Data;

@Data
public class CategoryVo {
	private int cateNum;
	private String cateName;
	private String cateCode;
	private String cateParent;
}
