package com.kh.mw.vo;

import lombok.Data;

@Data
public class CheckVo {
	private String userid;
	private String v_hall;
	private String v_dress;
	private String v_photo;
	private String v_beauty;
	private String v_shoot;
	private String v_card;
	private String v_helper;
	private String v_flower;
	private String v_final;
	private String v_end;
}
