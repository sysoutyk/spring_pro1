package com.kh.mw.vo;

import lombok.Data;

@Data
public class GuestVo {
	private int g_no;
	private String g_name;
	private String g_phonenumber;
	private String userid;
}
