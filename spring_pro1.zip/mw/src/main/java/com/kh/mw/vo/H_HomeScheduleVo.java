package com.kh.mw.vo;

import lombok.Data;

@Data
public class H_HomeScheduleVo {
	private int h_no;
	private int hs_no;
	private String hs_starttime;
	private String hs_endtime;
	private String hs_event;
}
