package com.kh.mw.vo;

import lombok.Data;

@Data
public class H_HomeVo {
	private String userid;
	private int h_no;
	private String h_pic;
	private String h_weddate;
	private String h_wedloc;
	private String h_gname;
	private String h_bname;
}
