package com.kh.mw.vo;

import lombok.Data;

@Data
public class H_OurstoryVo {
	private String userid;
	private String o_pic;
	private String o_title;
	private String o_content;
}
