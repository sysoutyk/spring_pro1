package com.kh.mw.vo;

import lombok.Data;

@Data
public class H_PhotosDataVo {
	private int p_no;
	private int pd_no;
	private String pd_pic;
	private String pd_pdate;
	private String pd_text;
	private String pd_title;
}
