package com.kh.mw.vo;

import lombok.Data;

@Data
public class H_PhotosVo {
	private String userid;
	private int p_no;
}
