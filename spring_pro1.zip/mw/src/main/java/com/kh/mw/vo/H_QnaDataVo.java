package com.kh.mw.vo;

import lombok.Data;

@Data
public class H_QnaDataVo {
	private int q_no;
	private int qd_no;
	private String qd_q;
	private String qd_a;
}
