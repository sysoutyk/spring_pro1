package com.kh.mw.vo;

import lombok.Data;

@Data
public class H_QnaVo {
	private String userid;
	private int q_no;
}
