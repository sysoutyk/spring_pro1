package com.kh.mw.vo;

import lombok.Data;

@Data
public class H_TempPhotosVo {
	private String userid;
	private String tp_htitlepic;
	private String tp_hspic;
	private String tp_mpic;
	private String tp_titlepic;
}
