package com.kh.mw.vo;

import lombok.Data;

@Data
public class H_TravelVo {
	private String userid;
	private String t_pic;
	private String t_wedloc;
	private String t_text;
}
