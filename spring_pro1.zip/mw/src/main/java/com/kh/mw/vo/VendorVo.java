package com.kh.mw.vo;

import lombok.Data;

@Data
public class VendorVo {
	private int v_no;
	private String cateCode;
	private String v_name;
	private String v_pic;
	private String v_link;
	private int v_score;
	private String v_adress;
	private String v_number;
	private String v_type;
}
