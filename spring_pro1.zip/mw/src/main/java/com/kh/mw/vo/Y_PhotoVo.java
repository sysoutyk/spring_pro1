package com.kh.mw.vo;

import lombok.Data;

@Data
public class Y_PhotoVo {
	private String userid;
	private String mespic;
	private String footer;
	private String footerpic;
}
