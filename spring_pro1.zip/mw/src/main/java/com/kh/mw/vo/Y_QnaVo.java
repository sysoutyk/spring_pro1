package com.kh.mw.vo;

import lombok.Data;

@Data
public class Y_QnaVo {
	private String userid;
	private int qno;
	private String ques;
	private String answer;
	private int likecount;
	
}
