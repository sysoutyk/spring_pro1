package com.kh.mw.vo;

import lombok.Data;

@Data
public class Y_StoryVo {
	private String userid;
	private String story_one_title;
	private String story_one_con;
	private String story_one_pic;
	private String story_two_title;
	private String story_two_con;
	private String story_two_pic;
}
