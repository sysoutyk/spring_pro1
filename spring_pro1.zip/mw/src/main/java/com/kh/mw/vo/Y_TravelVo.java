package com.kh.mw.vo;

import lombok.Data;

@Data
public class Y_TravelVo {
	private String userid;
	private String wedPlace;
	private String tvl_addr;
	private String tvlDetail;
	private String mapPic;
}
